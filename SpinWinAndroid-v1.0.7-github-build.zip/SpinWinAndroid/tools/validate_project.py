#!/usr/bin/env python3
"""Offline integrity checks for the Spin & Win Android source project.

This validates project structure and referenced assets only. It does not
replace Gradle/Kotlin compilation or an Android device test.
"""
from pathlib import Path
import re
import sys

root = Path(__file__).resolve().parents[1]
main = root / "app/src/main/java/com/arcadelab/spinwin/MainActivity.kt"
gradle = root / "app/build.gradle.kts"
manifest = root / "app/src/main/AndroidManifest.xml"
assets = root / "app/src/main/assets"
required = [
    root / "settings.gradle.kts", root / "build.gradle.kts",
    gradle, manifest, main,
]
missing = [str(p.relative_to(root)) for p in required if not p.is_file()]
source = main.read_text(errors="replace") if main.exists() else ""
gradle_text = gradle.read_text(errors="replace") if gradle.exists() else ""
manifest_text = manifest.read_text(errors="replace") if manifest.exists() else ""

graphics = assets / "decoded"
audio = assets / "audio"
pngs = sorted(graphics.glob("*.png")) if graphics.exists() else []
oggs = sorted(audio.glob("*.ogg")) if audio.exists() else []

# Resolve literal loadGraphic("name") references.
graphic_names = set(re.findall(r'loadGraphic\("([^"]+)"\)', source))
# Resolve dynamically generated numbered graphic keys used by the mini-game map.
for i in range(1, 13):
    graphic_names.add(f"Game{i:02d}Key")
missing_graphics = sorted(n for n in graphic_names if not (graphics / f"{n}.png").is_file())

# Resolve every literal sound name in the SoundPool load list.
audio_block = re.search(r'val audioFiles\s*=\s*listOf\((.*?)\)', source, re.S)
audio_names = re.findall(r'"([^"]+)"', audio_block.group(1)) if audio_block else []
missing_audio = sorted(n for n in audio_names if not (audio / f"{n}.ogg").is_file())

checks = {
    "required Android project files": not missing,
    "decoded PNG count is 32": len(pngs) == 32,
    "OGG audio count is 62": len(oggs) == 62,
    "all referenced graphics exist": not missing_graphics,
    "all SoundPool audio references exist": bool(audio_names) and not missing_audio,
    "OGG assets configured uncompressed": 'noCompress += "ogg"' in gradle_text,
    "launcher activity declared": 'android:name=".MainActivity"' in manifest_text and 'android.intent.action.MAIN' in manifest_text,
    "MainActivity source is present": "class MainActivity" in source,
}
for label, ok in checks.items():
    print(("PASS" if ok else "FAIL") + "  " + label)
if missing:
    print("Missing project files:", ", ".join(missing))
if missing_graphics:
    print("Missing graphics:", ", ".join(missing_graphics))
if missing_audio:
    print("Missing audio:", ", ".join(missing_audio))
print(f"INFO  {len(graphic_names)} graphic names checked; {len(audio_names)} SoundPool audio names checked")
print("LIMIT  Static asset validation only; no Kotlin compile, APK build, emulator, or device test.")
sys.exit(0 if all(checks.values()) else 1)
