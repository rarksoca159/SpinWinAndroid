#!/usr/bin/env python3
"""Decode Arcade Lab Spin & Win GFX files to PNG. Requires Pillow and NumPy."""
from pathlib import Path
import struct, sys
import numpy as np
from PIL import Image

def decode(src, dst):
    data = Path(src).read_bytes()
    if data[:8] != b"1XFGCSED":
        raise ValueError(f"{src}: unsupported signature")
    info, image_tag = data.find(b"OFNI"), data.find(b"EGMI")
    if info < 0 or image_tag < 0:
        raise ValueError(f"{src}: missing INFO/IMGE chunk")
    info_size = struct.unpack_from("<I", data, info+4)[0]
    width, height, bpp = struct.unpack_from("<III", data, info+8)
    size = struct.unpack_from("<I", data, image_tag+4)[0]
    payload = data[image_tag+8:image_tag+8+size]
    if size != width*height*bpp//8 or len(payload) != size:
        raise ValueError(f"{src}: invalid pixel payload")
    if bpp == 24:
        image = Image.frombytes("RGB", (width,height), payload)
    elif bpp == 16:
        px = np.frombuffer(payload, dtype="<u2").reshape(height,width)
        rgb = np.stack([((px>>11)&31)*255//31, ((px>>5)&63)*255//63, (px&31)*255//31], axis=-1)
        image = Image.fromarray(rgb.astype("uint8"), "RGB")
    else:
        raise ValueError(f"{src}: unsupported {bpp}-bit pixels")
    image.save(dst)
    print(f"{src} -> {dst}: {width}x{height}, {bpp}-bit (INFO chunk {info_size})")

if __name__ == "__main__":
    if len(sys.argv) != 3:
        raise SystemExit("Usage: decode_gfx.py INPUT.gfx OUTPUT.png")
    decode(sys.argv[1], sys.argv[2])
