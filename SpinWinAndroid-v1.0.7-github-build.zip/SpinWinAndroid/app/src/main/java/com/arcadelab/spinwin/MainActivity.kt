package com.arcadelab.spinwin

import android.app.Activity
import android.os.Bundle
import android.view.View
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Color
import android.graphics.RectF
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.SoundPool
import android.media.AudioAttributes
import android.content.SharedPreferences
import org.json.JSONArray
import android.view.MotionEvent
import kotlin.math.*
import kotlin.random.Random

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        setContentView(SpinWinView(this))
    }
}

private class SpinWinView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val prefs: SharedPreferences = context.getSharedPreferences("spinwin_progress", Context.MODE_PRIVATE)
    private val soundPool: SoundPool = SoundPool.Builder()
        .setMaxStreams(6)
        .setAudioAttributes(AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
        .build()
    private val sounds = mutableMapOf<String, Int>()
    private var trophyScreen = false
    private var highScoreScreen = false
    private var highScores = loadHighScores()
    private var unlockedTrophies = (prefs.getStringSet("trophies", emptySet()) ?: emptySet()).toMutableSet()
    private var lifetimeCredits = prefs.getInt("lifetime_credits", 0)
    private var gamesPlayed = (prefs.getStringSet("games_played", emptySet()) ?: emptySet()).toMutableSet()
    private fun loadGraphic(name: String): Bitmap? = try {
        context.assets.open("decoded/$name.png").use { BitmapFactory.decodeStream(it) }
    } catch (_: Exception) { null }
    private val originalBackdrop: Bitmap? = loadGraphic("Backdrop")
    private val titleBackground: Bitmap? = loadGraphic("TitleBG")
    private val prizesBackground: Bitmap? = loadGraphic("PricesBG")
    private val miniGameArt = (1..12).associate { i -> "Game%02d".format(i) to loadGraphic("Game%02dKey".format(i)) }
    private val miniGameArtIndex = mapOf("Bonus Ladder" to 1, "Pick a Number" to 2, "Scratch a Combo" to 3, "Horse Racing" to 4, "Quiz" to 5, "Cherry Triple" to 6, "Dice" to 7, "Find the Spades" to 8, "Memory" to 12)
    private val modes = listOf("Original Classic", "Classic Stairway", "Classic Memory", "Marathon", "Fortune")
    private val allMiniGames = listOf("Memory", "Bonus Ladder", "Pick a Number", "Scratch a Combo", "Horse Racing", "Quiz", "Cherry Triple", "Dice", "Find the Spades")
    private val startingSpins = listOf(20, 20, 20, 100, 0)
    private val labels = listOf("100", "250", "500", "750", "+1", "+2", "2X", "GAME", "GAME", "GAME", "GAME", "−1")
    private val palette = listOf(0xFF315E83.toInt(),0xFFB34C32.toInt(),0xFF39805A.toInt(),0xFF8A6334.toInt(),
        0xFF6A4C93.toInt(),0xFF397C83.toInt(),0xFFC18C25.toInt(),0xFF9C3D42.toInt(),
        0xFF315E83.toInt(),0xFF39805A.toInt(),0xFF8A6334.toInt(),0xFF6A4C93.toInt())
    private var menu = true
    private var mode = 0
    private var spins = 20
    private var credits = 0
    private var rotation = 0f
    private var busy = false
    private var message = "Tap SPIN to play"
    private var miniGame: String? = null
    private var memoryValues = mutableListOf<Int>()
    private var memoryOpen = mutableSetOf<Int>()
    private var memoryMatched = mutableSetOf<Int>()
    private var memoryMoves = 8
    private var memoryFirst = -1
    private var pendingScore = 0
    private var pickTarget = 1
    private var pickOpened = mutableSetOf<Int>()
    private var scratchValues = mutableListOf<Int>()
    private var scratchOpened = mutableSetOf<Int>()
    private var ladderStep = 0
    private var ladderLit = false
    private var horseResult = -1
    private var horseBet = -1
    private var horseFinishingOrder = mutableListOf<Int>()
    private var quizQuestion = 0
    private var quizChoice = -1
    private var quizCorrect = -1
    private var cherryReels = mutableListOf("?", "?", "?")
    private var cherryPlayed = false
    private var diceOne = 0
    private var diceTwo = 0
    private var diceThree = 0
    private var dicePlayed = false
    private var spadeGrid = mutableListOf<Boolean>()
    private var spadeOpened = mutableSetOf<Int>()
    private var cherryPlays = 0
    private var cherryTotal = 0
    private var doubleNextGame = false
    private var fortuneSpins = 0
    private var wheelTokens = mutableListOf<Int>()

    init {
        val audioFiles = listOf("Click", "Spin1", "Spin2", "Success1", "Success2", "Wrong1", "Wrong2", "Dice1", "HorseGoal", "HorseApplause", "TrophyReceive", "TrophyPick", "TrophyPut", "TrophyLoop", "Fanfare", "X2Bonus", "GameOver", "ButtonFlash")
        audioFiles.forEach { name ->
            try { context.assets.openFd("audio/$name.ogg").use { afd -> sounds[name] = soundPool.load(afd, 1) } }
            catch (_: Exception) { }
        }
    }

    private fun play(name: String) { sounds[name]?.let { soundPool.play(it, 0.85f, 0.85f, 1, 0, 1f) } }

    private fun unlock(id: String) {
        if (unlockedTrophies.add(id)) {
            prefs.edit().putStringSet("trophies", unlockedTrophies.toSet()).apply()
            play("TrophyReceive")
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(26, 22, 17))
        val w = width.toFloat()
        val h = height.toFloat()
        drawText(canvas, "SPIN & WIN", w/2, h*.11f, h*.075f, 0xFFFFD56A.toInt(), true)
        if (trophyScreen) {
            prizesBackground?.let { canvas.drawBitmap(it, null, RectF(0f, 0f, w, h), paint) }
            if (highScoreScreen) {
                drawText(canvas, "HIGH SCORES", w/2, h*.22f, h*.045f, 0xFFFFD56A.toInt(), true)
                if (highScores.isEmpty()) drawText(canvas, "No scores recorded yet", w/2, h*.43f, h*.032f, Color.WHITE)
                highScores.take(5).forEachIndexed { i, score ->
                    val y=h*(.34f+i*.105f)
                    paint.color=0x9951402B.toInt()
                    canvas.drawRoundRect(w*.22f,y,w*.78f,y+h*.075f,10f,10f,paint)
                    drawText(canvas, "${i+1}.     $score credits", w/2, y+h*.052f, h*.03f, Color.WHITE, true)
                }
                drawText(canvas, "Best score is saved on this device", w/2,h*.83f,h*.022f,Color.WHITE)
            } else {
                drawText(canvas, "TROPHY ROOM", w/2, h*.19f, h*.045f, 0xFFFFD56A.toInt(), true)
                val trophyNames = listOf("First Prize", "High Roller", "Arcade Explorer", "Fortune 50K", "Marathon Finisher")
                val trophyIds = listOf("first_prize", "high_roller", "explorer", "fortune", "marathon")
                trophyNames.forEachIndexed { i, name ->
                    val y = h*(.27f+i*.105f)
                    paint.color = if (trophyIds[i] in unlockedTrophies) 0xFF8A6334.toInt() else 0xFF51402B.toInt()
                    canvas.drawRoundRect(w*.20f,y,w*.80f,y+h*.075f,12f,12f,paint)
                    drawText(canvas, (if (trophyIds[i] in unlockedTrophies) "★  " else "LOCKED  ")+name, w/2,y+h*.050f,h*.027f,Color.WHITE,true)
                }
                drawText(canvas, "Lifetime credits: $lifetimeCredits", w/2,h*.84f,h*.025f,Color.WHITE)
                paint.color=0xFF8A6334.toInt(); canvas.drawRoundRect(w*.24f,h*.88f,w*.76f,h*.94f,10f,10f,paint)
                drawText(canvas,"HIGH SCORES",w/2,h*.922f,h*.024f,Color.WHITE,true)
            }
            paint.color=0xFF34734B.toInt(); canvas.drawRoundRect(w*.39f,h*.95f,w*.61f,h*.995f,10f,10f,paint)
            drawText(canvas,"BACK",w/2,h*.985f,h*.022f,Color.WHITE,true)
            return
        }
        if (miniGame != null) {
            drawMiniGame(canvas, w, h)
            return
        }
        if (menu) {
            titleBackground?.let { canvas.drawBitmap(it, null, RectF(0f, 0f, w, h), paint) }
            drawText(canvas, "ARCADE LAB • ANDROID PORT", w/2, h*.19f, h*.027f, Color.LTGRAY)
            modes.forEachIndexed { i, label ->
                val bh=h*.075f; val y=h*.30f+i*(bh+h*.014f)
                paint.color=if(i==mode) 0xDDB77B27.toInt() else 0x9951402B.toInt()
                canvas.drawRoundRect(w*.29f,y,w*.71f,y+bh,12f,12f,paint)
                drawText(canvas,label,w/2,y+bh*.66f,h*.030f,Color.WHITE,true)
            }
            paint.color=0xFF34734B.toInt()
            canvas.drawRoundRect(w*.39f,h*.91f,w*.61f,h*.99f,12f,12f,paint)
            drawText(canvas,"START",w/2,h*.965f,h*.035f,Color.WHITE,true)
            paint.color=0xFF51402B.toInt(); canvas.drawRoundRect(w*.77f,h*.91f,w*.96f,h*.99f,12f,12f,paint)
            drawText(canvas,"TROPHIES",w*.865f,h*.965f,h*.022f,Color.WHITE,true)
        } else {
            val bg = originalBackdrop
            if (bg != null) {
                canvas.drawBitmap(bg, null, RectF(0f, 0f, w, h), paint)
                if (busy || rotation != 0f) {
                    // Rotate only the colored wheel track, leaving the frame, pointer and side panel fixed.
                    val cx = w * (224f / 640f)
                    val cy = h * (240f / 480f)
                    val outer = min(w * (202f / 640f), h * (202f / 480f))
                    val inner = min(w * (112f / 640f), h * (112f / 480f))
                    val ring = android.graphics.Path().apply {
                        fillType = android.graphics.Path.FillType.EVEN_ODD
                        addCircle(cx, cy, outer, android.graphics.Path.Direction.CW)
                        addCircle(cx, cy, inner, android.graphics.Path.Direction.CCW)
                    }
                    val save = canvas.save()
                    canvas.clipPath(ring)
                    canvas.rotate(rotation, cx, cy)
                    canvas.drawBitmap(bg, null, RectF(0f, 0f, w, h), paint)
                    canvas.restoreToCount(save)
                }
                // Overlay the changing values in the original game's coin and status panels.
                drawText(canvas, "$credits", w*.83f, h*.66f, h*.040f, 0xFFFFD56A.toInt(), true)
                drawText(canvas, if(mode==4) "FORTUNE  $fortuneSpins" else "$spins SPINS", w*.83f, h*.91f, h*.025f, Color.WHITE, true)
                if (doubleNextGame) drawText(canvas, "2X READY", w*.83f, h*.84f, h*.022f, 0xFFFFFF66.toInt(), true)
                if (busy) drawText(canvas, "SPINNING…", w*.50f, h*.52f, h*.035f, Color.WHITE, true)
                else if (message != "Tap SPIN to play") {
                    drawText(canvas, message.take(36), w*.50f, h*.52f, h*.026f, Color.WHITE, true)
                }
            } else {
                drawText(canvas,modes[mode],w*.16f,h*.22f,h*.035f,0xFFFFD56A.toInt(),true)
                drawText(canvas,"CREDITS  $credits",w*.16f,h*.30f,h*.032f,Color.WHITE,true)
                drawText(canvas,"SPINS  ${if(mode==4) "—" else spins}",w*.16f,h*.37f,h*.032f,Color.WHITE,true)
                val cx=w*.62f; val cy=h*.52f; val r=min(w*.31f,h*.37f)
                labels.indices.forEach { i ->
                    paint.color=palette[i]
                    canvas.drawArc(RectF(cx-r,cy-r,cx+r,cy+r),rotation+i*30f,30.5f,true,paint)
                    val a=Math.toRadians((rotation+i*30f+15).toDouble())
                    drawText(canvas,labels[i],cx+cos(a).toFloat()*r*.68f,cy+sin(a).toFloat()*r*.68f+h*.01f,h*.027f,Color.WHITE,true)
                }
                paint.color=0xFFFFD56A.toInt(); canvas.drawCircle(cx,cy,r*.13f,paint)
                paint.color=Color.BLACK; canvas.drawCircle(cx,cy,r*.055f,paint)
                paint.color=Color.WHITE
                val pointer=android.graphics.Path().apply { moveTo(cx,cy-r-12); lineTo(cx-18,cy-r-42); lineTo(cx+18,cy-r-42); close() }
                canvas.drawPath(pointer,paint)
                paint.color=if(busy) 0xFF777777.toInt() else 0xFF34734B.toInt()
                canvas.drawRoundRect(w*.42f,h*.84f,w*.82f,h*.96f,18f,18f,paint)
                drawText(canvas,if(busy) "SPINNING…" else "SPIN",w*.62f,h*.915f,h*.055f,Color.WHITE,true)
                drawText(canvas,message,w*.62f,h*.79f,h*.027f,0xFFFFD56A.toInt())
                drawText(canvas,"MENU",w*.09f,h*.93f,h*.03f,Color.LTGRAY,true)
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action != MotionEvent.ACTION_UP) return true
        val x=event.x/width; val y=event.y/height
        if (trophyScreen) {
            if (highScoreScreen) {
                if (y > .92f) highScoreScreen = false
            } else if (y > .86f && y < .95f) highScoreScreen = true
            else if (y > .94f) trophyScreen = false
        } else if (miniGame != null) {
            play("Click")
            handleMiniGameTap(x, y)
        } else if (menu) {
            if (x > .75f && y > .88f) { trophyScreen = true; play("TrophyLoop") }
            else {
            val row=((y-.30f)/.089f).toInt()
            if(row in modes.indices) mode=row
            else if(y>.90f && x<.70f) { menu=false; spins=startingSpins[mode]; credits=0; fortuneSpins=0; doubleNextGame=false; buildWheel(); message="Tap SPIN to play" }
            }
        } else if(x<.2f && y>.84f) { recordHighScore(); if (mode==3 && spins<=0) unlock("marathon"); menu=true; play("MenuOpen") }
        else if(!busy && ((x>.70f && x<.91f && y>.68f && y<.86f) || (x>.35f && y>.80f))) spin()
        invalidate()
        return true
    }

    private fun buildWheel() {
        // Token counts are taken directly from the original v1.01 ReadMe.
        val (scores, games, bonuses) = when (mode) {
            1 -> Triple(14, 10, 4)
            2 -> Triple(26, 0, 2)
            4 -> Triple(15, 11, 2)
            else -> Triple(13, 10, 5) // Original Classic and Marathon
        }
        wheelTokens.clear()
        repeat(scores) { wheelTokens += Random.nextInt(0, 4) }
        repeat(games) { wheelTokens += Random.nextInt(7, 15) }
        val bonusPool = if (bonuses == 2) listOf(4, 5, 6, 11) else listOf(4, 5, 6, 11)
        repeat(bonuses) { wheelTokens += bonusPool.random() }
        wheelTokens.shuffle()
    }

    private fun spin() {
        if(mode!=4 && spins<=0) { message="Game over — return to menu"; return }
        if (wheelTokens.isEmpty()) buildWheel()
        busy=true
        play("Spin1")
        if(mode!=4) spins-- else fortuneSpins++
        val chosen=wheelTokens.random()
        val start=rotation
        val delta=1800f+(360f-chosen*30f-start%360f)
        val began=System.currentTimeMillis()
        fun animate() {
            val t=((System.currentTimeMillis()-began)/2600f).coerceIn(0f,1f)
            rotation=start+delta*(1f-(1f-t).pow(4))
            invalidate()
            if(t<1f) postDelayed({ animate() },16) else {
                busy=false
                when(chosen) {
                    in 0..3 -> { pendingScore=labels[chosen].toInt(); startMiniGame("Memory") }
                    4 -> { if(mode!=4) spins++; message="Bonus: +1 spin" }
                    5 -> { if(mode!=4) spins+=2; message="Bonus: +2 spins" }
                    6 -> { doubleNextGame=true; message="2X bonus: next game-token prize is doubled" }
                    11 -> message="Lost this spin"
                    in 7..14 -> startMiniGame(listOf("Bonus Ladder","Pick a Number","Scratch a Combo","Horse Racing","Quiz","Cherry Triple","Dice","Find the Spades")[chosen-7])
                }
                if(mode==4 && credits>=50000) { message="FORTUNE COMPLETE! ${fortuneSpins} spins"; unlock("fortune"); play("Fanfare") }
                invalidate()
            }
        }
        animate()
    }

    private fun startMiniGame(name: String) {
        miniGame = name
        gamesPlayed.add(name)
        prefs.edit().putStringSet("games_played", gamesPlayed.toSet()).apply()
        if (gamesPlayed.containsAll(allMiniGames)) unlock("explorer")
        when (name) {
            "Memory" -> {
                memoryValues = (listOf(0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7).shuffled()).toMutableList()
                memoryOpen.clear(); memoryMatched.clear()
                memoryMoves = if (mode == 2) 3 else 8
                memoryFirst = -1
            }
            "Pick a Number" -> { pickTarget = (1..16).random(); pickOpened.clear() }
            "Scratch a Combo" -> {
                val reward = listOf(10,250,1250,2500,5000).random()
                scratchValues = (listOf(reward,reward) + (1..7).map { listOf(10,250,1250,2500,5000).random() }).shuffled().toMutableList()
                scratchOpened.clear()
            }
            "Bonus Ladder" -> { ladderStep=0; ladderLit=false; pulseLadderLight() }
            "Horse Racing" -> { horseBet=-1; horseResult=-1; horseFinishingOrder.clear() }
            "Quiz" -> {
                quizQuestion = Random.nextInt(quizQuestions.size)
                quizChoice = -1
                quizCorrect = quizQuestions[quizQuestion].correct
            }
            "Cherry Triple" -> {
                cherryReels = mutableListOf("?", "?", "?")
                cherryPlayed = false
                cherryPlays = 0
                cherryTotal = 0
            }
            "Dice" -> {
                diceOne = 0; diceTwo = 0; diceThree = 0; dicePlayed = false
            }
            "Find the Spades" -> {
                // Four hidden spades form one complete row or column on a 4x4 board.
                spadeGrid = MutableList(16) { false }
                val rowOrColumn = Random.nextInt(2)
                val line = Random.nextInt(4)
                for (i in 0..3) spadeGrid[if (rowOrColumn == 0) line * 4 + i else i * 4 + line] = true
                spadeOpened.clear()
            }
        }
        invalidate()
    }

    private fun pulseLadderLight() {
        val delay = (850L - ladderStep * 105L).coerceAtLeast(180L)
        postDelayed({
            if (miniGame == "Bonus Ladder") {
                ladderLit = !ladderLit
                invalidate()
                pulseLadderLight()
            }
        }, delay)
    }

    private fun handleMiniGameTap(x: Float, y: Float) {
        when (miniGame) {
            "Memory" -> {
                if (y > .88f) { finishMiniGame(); return }
                // Match the hit boxes to the 4x4 card positions drawn below.
                val col = ((x-.25f)/.125f).toInt()
                val row = ((y-.34f)/.13f).toInt()
                val idx=row*4+col
                if (col in 0..3 && row in 0..3 && idx !in memoryMatched &&
                    idx !in memoryOpen && memoryMoves>0 && memoryOpen.size<2) {
                    memoryOpen.add(idx)
                    if (memoryFirst < 0) {
                        memoryFirst=idx
                    } else {
                        val first = memoryFirst
                        memoryMoves--
                        memoryFirst=-1
                        if (memoryValues[first] == memoryValues[idx]) {
                            memoryMatched.add(first)
                            memoryMatched.add(idx)
                            if (memoryValues[idx] == 7) {
                                if (mode != 4) spins += 2
                                message = "You found +2 extra spins!"
                            } else {
                                addScoreCredits(pendingScore)
                                message = "Memory match! +$pendingScore credits"
                            }
                            memoryOpen.clear()
                            if (memoryMatched.size == 16) {
                                addScoreCredits(3500)
                                message = "Full board bonus! +3500 credits"
                                finishMiniGame()
                            } else if (memoryMoves <= 0) {
                                finishMiniGame()
                            }
                        } else {
                            message = "No match — try another pair"
                            // Briefly show both cards, then turn them face down.
                            postDelayed({
                                if (miniGame == "Memory") {
                                    memoryOpen.clear()
                                    if (memoryMoves <= 0) finishMiniGame()
                                    invalidate()
                                }
                            }, 650L)
                        }
                    }
                }
            }
            "Pick a Number" -> {
                if (y > .88f) { finishMiniGame(); return }
                // The visible number tiles start at x=.25, y=.36 and use
                // .125/.125 spacing; keep touch coordinates aligned with drawing.
                val col=((x-.25f)/.125f).toInt()
                val row=((y-.36f)/.125f).toInt()
                val n=row*4+col+1
                if(col in 0..3 && row in 0..3 && n !in pickOpened) {
                    pickOpened.add(n)
                    if(n==pickTarget) { awardGameTokenPrize((16-pickOpened.size)*100); finishMiniGame() }
                    else if(pickOpened.size==16) finishMiniGame()
                }
            }
            "Scratch a Combo" -> {
                if(y>.88f) { finishMiniGame(); return }
                // Align hit boxes with the 3x3 scratch cards rendered at
                // x=.30/.14 spacing and y=.36/.17 spacing.
                val col=((x-.30f)/.14f).toInt()
                val row=((y-.36f)/.17f).toInt()
                val idx=row*3+col
                if(col in 0..2 && row in 0..2 && idx !in scratchOpened) {
                    scratchOpened.add(idx)
                    val counts=scratchOpened.map { scratchValues[it] }.groupingBy { it }.eachCount()
                    val match=counts.entries.firstOrNull { it.value>=2 }
                    if(match!=null) { awardGameTokenPrize(match.key); finishMiniGame() }
                    else if(scratchOpened.size==9) finishMiniGame()
                }
            }
            "Bonus Ladder" -> {
                if(y>.88f) { finishMiniGame(); return }
                if(ladderLit) {
                    ladderStep++
                    if(ladderStep>=6) { awardGameTokenPrize(3100); finishMiniGame() }
                    else ladderLit=false
                } else { message="Missed the green light — no prize"; play("Wrong1"); finishMiniGame() }
            }
            "Horse Racing" -> {
                if(y>.88f) { finishMiniGame(); return }
                if(horseBet<0 && x in .27f.. .73f && y in .37f.. .82f) {
                    // Horse rows are drawn at .37 + i*.12 with .09 height.
                    horseBet=(((y-.37f)/.12f).toInt()).coerceIn(0,3)
                    // Generate a complete finishing order, then pay according to the
                    // position of the horse the player actually selected.
                    horseFinishingOrder=(0..3).shuffled().toMutableList()
                    horseResult=horseFinishingOrder.indexOf(horseBet) // 0 = first, 3 = fourth
                    play(if (horseResult == 0) "HorseApplause" else "HorseGoal")
                    val prize = when (horseResult) { 0 -> 4000; 1 -> 750; 2 -> 250; else -> 0 }
                    if (prize > 0) awardGameTokenPrize(prize)
                    else message = "Your horse finished fourth — no prize"
                    finishMiniGame()
                }
            }
            "Quiz" -> {
                if (y > .88f) { finishMiniGame(); return }
                if (quizChoice < 0 && x in .23f.. .77f && y in .39f.. .81f) {
                    quizChoice = (((y-.39f)/.105f).toInt()).coerceIn(0,3)
                    if (quizChoice == quizCorrect) awardGameTokenPrize(2000)
                    else { message = "Incorrect answer — no prize"; play("Wrong2") }
                    finishMiniGame()
                }
            }
            "Cherry Triple" -> {
                if (y > .88f) { finishMiniGame(); return }
                if (cherryPlays < 5) {
                    val symbols = listOf("🍒", "★", "7", "●")
                    cherryReels = MutableList(3) { symbols.random() }
                    cherryPlays++
                    val cherries = cherryReels.count { it == "🍒" }
                    val prize = when {
                        cherryReels.distinct().size == 1 && cherries == 3 -> 2500
                        cherryReels.distinct().size == 1 -> 1500
                        cherries == 2 -> 1000
                        cherries == 1 -> 500
                        else -> 0
                    }
                    if (prize > 0) { awardGameTokenPrize(prize); cherryTotal += prize }
                    cherryPlayed = cherryPlays >= 5
                    if (cherryPlayed) finishMiniGame()
                }
            }
            "Dice" -> {
                if (y > .88f) { finishMiniGame(); return }
                if (!dicePlayed) {
                    play("Dice1")
                    diceOne = Random.nextInt(1, 7)
                    diceTwo = Random.nextInt(1, 7)
                    diceThree = Random.nextInt(1, 7)
                    dicePlayed = true
                    // Manual: three dice pay 100x, 200x and 300x their respective face values.
                    awardGameTokenPrize(diceOne * 100 + diceTwo * 200 + diceThree * 300)
                    finishMiniGame()
                }
            }
            "Find the Spades" -> {
                if (y > .88f) { finishMiniGame(); return }
                val col = ((x - .25f) / .125f).toInt()
                val row = ((y - .37f) / .12f).toInt()
                val idx = row * 4 + col
                if (col in 0..3 && row in 0..3 &&
                    x in .25f.. .73f && y in .37f.. .82f && idx !in spadeOpened) {
                    spadeOpened.add(idx)
                    val allFourFound = spadeOpened.count { spadeGrid[it] } == 4
                    if (allFourFound) {
                        // The four spades are generated in one complete row or column.
                        // Award the remaining unopened-door value only after all four are found.
                        val remaining = 16 - spadeOpened.size
                        awardGameTokenPrize(remaining * 150)
                        finishMiniGame()
                    } else if (spadeOpened.size == 16) {
                        message = "No more doors — no prize"
                        finishMiniGame()
                    }
                }
            }
            else -> {
                // Other original mini-games are queued for later reconstruction.
                if(y>.88f) finishMiniGame()
                else { message="$miniGame is next in the implementation queue"; invalidate() }
            }
        }
        invalidate()
    }

    private fun loadHighScores(): MutableList<Int> {
        return try {
            val array = JSONArray(prefs.getString("high_scores", "[]"))
            MutableList(array.length()) { array.getInt(it) }.sortedDescending().take(5).toMutableList()
        } catch (_: Exception) { mutableListOf() }
    }

    private fun recordHighScore() {
        if (credits <= 0) return
        highScores.add(credits)
        highScores = highScores.sortedDescending().take(5).toMutableList()
        val array = JSONArray()
        highScores.forEach { array.put(it) }
        prefs.edit().putString("high_scores", array.toString()).apply()
    }

    private fun addScoreCredits(amount: Int) {
        credits += amount
        lifetimeCredits += amount
        prefs.edit().putInt("lifetime_credits", lifetimeCredits).apply()
        if (lifetimeCredits >= 10000) unlock("high_roller")
    }

    private fun awardGameTokenPrize(amount: Int) {
        val paid = if (doubleNextGame) amount * 2 else amount
        credits += paid
        lifetimeCredits += paid
        prefs.edit().putInt("lifetime_credits", lifetimeCredits).apply()
        if (paid > 0) unlock("first_prize")
        if (lifetimeCredits >= 10000) unlock("high_roller")
        play(if (doubleNextGame) "X2Bonus" else "Success1")
        if (doubleNextGame) message = "2X prize! +$paid credits"
        else message = "+$paid credits"
    }

    private fun finishMiniGame() {
        val finishedGame = miniGame
        miniGame=null
        // Score-token Memory and bonus tokens do not consume the 2x star.
        // It is consumed after a game-token mini-game, even if that game paid nothing.
        if (finishedGame != "Memory") doubleNextGame = false
        if (message == "Tap SPIN to play" || message == "Mini-game complete — tap SPIN")
            message="Mini-game complete — tap SPIN"
        invalidate()
    }

    private fun drawMiniGame(c: Canvas, w: Float, h: Float) {
        paint.color=0xFF201A30.toInt(); c.drawRoundRect(w*.04f,h*.13f,w*.96f,h*.97f,24f,24f,paint)
        val artIndex = miniGameArtIndex[miniGame]
        val art = artIndex?.let { miniGameArt["Game%02d".format(it)] }
        if (art != null) {
            // Preserve the original 640px artwork proportions; magenta key areas are transparent.
            val bounds = RectF(w*.055f, h*.22f, w*.945f, h*.86f)
            val scale = min(bounds.width()/art.width, bounds.height()/art.height)
            val dw = art.width*scale; val dh = art.height*scale
            val dst = RectF(bounds.centerX()-dw/2f, bounds.centerY()-dh/2f, bounds.centerX()+dw/2f, bounds.centerY()+dh/2f)
            c.drawBitmap(art, null, dst, paint)
        }
        drawText(c,miniGame ?: "",w/2,h*.22f,h*.05f,0xFFFFD56A.toInt(),true)
        when(miniGame) {
            "Memory" -> {
                drawText(c,"Pair attempts left: $memoryMoves",w/2,h*.29f,h*.027f,Color.WHITE,true)
                for(i in 0..15) {
                    val col=i%4; val row=i/4
                    val x=w*(.25f+col*.125f); val y=h*(.34f+row*.13f)
                    paint.color=when { i in memoryMatched -> 0xFF34734B.toInt(); i in memoryOpen -> 0xFFB77B27.toInt(); else -> 0xFF315E83.toInt() }
                    c.drawRoundRect(x,y,x+w*.105f,y+h*.105f,10f,10f,paint)
                    if(i in memoryOpen || i in memoryMatched) drawText(c,(memoryValues[i]+1).toString(),x+w*.052f,y+h*.07f,h*.04f,Color.WHITE,true)
                    else drawText(c,"?",x+w*.052f,y+h*.07f,h*.04f,Color.WHITE,true)
                }
            }
            "Pick a Number" -> {
                drawText(c,"Find the hidden number (1–16)",w/2,h*.30f,h*.028f,Color.WHITE)
                for(i in 1..16) {
                    val col=(i-1)%4; val row=(i-1)/4
                    val x=w*(.25f+col*.125f); val y=h*(.36f+row*.125f)
                    paint.color=if(i in pickOpened) 0xFF51402B.toInt() else 0xFF34734B.toInt()
                    c.drawRoundRect(x,y,x+w*.105f,y+h*.10f,9f,9f,paint)
                    drawText(c,if(i in pickOpened) (if(i==pickTarget) "✓" else "×") else i.toString(),x+w*.052f,y+h*.068f,h*.035f,Color.WHITE,true)
                }
            }
            "Scratch a Combo" -> {
                drawText(c,"Reveal two matching prizes",w/2,h*.30f,h*.028f,Color.WHITE)
                for(i in 0..8) {
                    val col=i%3; val row=i/3
                    val x=w*(.30f+col*.14f); val y=h*(.36f+row*.17f)
                    paint.color=if(i in scratchOpened) 0xFFB77B27.toInt() else 0xFF397C83.toInt()
                    c.drawRoundRect(x,y,x+w*.12f,y+h*.13f,9f,9f,paint)
                    drawText(c,if(i in scratchOpened) scratchValues[i].toString() else "SCRATCH",x+w*.06f,y+h*.085f,h*.022f,Color.WHITE,true)
                }
            }
            "Bonus Ladder" -> {
                drawText(c,"Tap while the green light is on!",w/2,h*.31f,h*.03f,Color.WHITE)
                for(i in 0..5) {
                    val y=h*(.75f-i*.075f)
                    paint.color=if(i<ladderStep) 0xFFB77B27.toInt() else if(i==ladderStep && ladderLit) 0xFF36B85D.toInt() else 0xFF51402B.toInt()
                    c.drawRoundRect(w*.32f,y,w*.68f,y+h*.055f,8f,8f,paint)
                    drawText(c,if(i<ladderStep) "✓" else "STEP ${i+1}",w/2,y+h*.04f,h*.025f,Color.WHITE,true)
                }
            }
            "Horse Racing" -> {
                drawText(c,"Choose a horse to place your bet",w/2,h*.31f,h*.03f,Color.WHITE)
                val names=listOf("MILKY WAY","PICKLE","THUNDER","COOL CASE")
                names.forEachIndexed { i,n ->
                    val y=h*(.37f+i*.12f)
                    paint.color=if (horseBet==i) 0xFFB77B27.toInt() else 0xFF397C83.toInt()
                    c.drawRoundRect(w*.27f,y,w*.73f,y+h*.09f,10f,10f,paint)
                    val place = if (horseFinishingOrder.isNotEmpty()) "  #${horseFinishingOrder.indexOf(i)+1}" else ""
                    drawText(c,n+place,w/2,y+h*.06f,h*.027f,Color.WHITE,true)
                }
            }
            "Quiz" -> {
                val q = quizQuestions[quizQuestion]
                drawText(c,q.prompt,w/2,h*.32f,h*.032f,Color.WHITE,true)
                q.answers.forEachIndexed { i, answer ->
                    val y=h*(.39f+i*.105f)
                    paint.color=if(quizChoice==i) 0xFFB77B27.toInt() else 0xFF315E83.toInt()
                    c.drawRoundRect(w*.23f,y,w*.77f,y+h*.085f,10f,10f,paint)
                    drawText(c,answer,w/2,y+h*.057f,h*.027f,Color.WHITE,true)
                }
            }
            "Cherry Triple" -> {
                drawText(c,"Play $cherryPlays of 5 — tap to spin",w/2,h*.33f,h*.03f,Color.WHITE)
                for (i in 0..2) {
                    val x=w*(.27f+i*.17f)
                    paint.color=0xFF8A6334.toInt()
                    c.drawRoundRect(x,h*.43f,x+w*.14f,h*.68f,14f,14f,paint)
                    drawText(c,cherryReels[i],x+w*.07f,h*.59f,h*.065f,Color.WHITE,true)
                }
                drawText(c,"Prize total: $cherryTotal",w/2,h*.77f,h*.027f,Color.WHITE)
            }
            "Dice" -> {
                drawText(c,"Roll three dice for a prize",w/2,h*.36f,h*.032f,Color.WHITE,true)
                if (dicePlayed) {
                    drawText(c,"$diceOne  +  $diceTwo  +  $diceThree",w/2,h*.57f,h*.075f,0xFFFFD56A.toInt(),true)
                } else drawText(c,"Tap to roll",w/2,h*.58f,h*.04f,Color.WHITE)
            }
            "Find the Spades" -> {
                drawText(c,"Find all four hidden spades",w/2,h*.32f,h*.027f,Color.WHITE,true)
                for (i in 0..15) {
                    val col=i%4; val row=i/4
                    val x=w*(.25f+col*.125f); val y=h*(.37f+row*.12f)
                    paint.color=if(i in spadeOpened) 0xFFB77B27.toInt() else 0xFF315E83.toInt()
                    c.drawRoundRect(x,y,x+w*.105f,y+h*.09f,8f,8f,paint)
                    val shown=if(i in spadeOpened) if(spadeGrid[i]) "♠" else "×" else "?"
                    drawText(c,shown,x+w*.052f,y+h*.063f,h*.035f,Color.WHITE,true)
                }
            }
            else -> drawText(c,"This mini-game will be implemented next.",w/2,h*.52f,h*.03f,Color.WHITE)
        }
        paint.color=0xFF34734B.toInt(); c.drawRoundRect(w*.38f,h*.88f,w*.62f,h*.95f,10f,10f,paint)
        drawText(c,"CONTINUE",w/2,h*.927f,h*.026f,Color.WHITE,true)
        drawText(c,"CREDITS: $credits",w*.18f,h*.94f,h*.022f,Color.WHITE,true)
    }

    private data class QuizQuestion(val prompt: String, val answers: List<String>, val correct: Int)
    private val quizQuestions = listOf(
        QuizQuestion("Which planet is called the Red Planet?", listOf("Venus", "Mars", "Jupiter", "Mercury"), 1),
        QuizQuestion("How many sides has a hexagon?", listOf("Five", "Six", "Seven", "Eight"), 1),
        QuizQuestion("Which animal is the tallest?", listOf("Giraffe", "Horse", "Elephant", "Camel"), 0),
        QuizQuestion("What is 9 × 8?", listOf("64", "70", "72", "81"), 2),
        QuizQuestion("Which ocean is the largest?", listOf("Indian", "Arctic", "Atlantic", "Pacific"), 3)
    )

    override fun onDetachedFromWindow() { super.onDetachedFromWindow(); soundPool.release() }

    private fun drawText(c:Canvas,s:String,x:Float,y:Float,size:Float,color:Int,bold:Boolean=false) {
        paint.color=color; paint.textSize=size; paint.textAlign=Paint.Align.CENTER
        paint.typeface=android.graphics.Typeface.create("sans-serif",
            if(bold) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
        c.drawText(s,x,y,paint)
    }
}
