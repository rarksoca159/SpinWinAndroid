# Spin & Win Android port — starter project

This is an early native Android prototype, not a finished port or verified APK.

## Open in Android Studio
Open this folder, install Android SDK Platform 35, then sync Gradle.

## Current prototype
- Landscape Android app with five mode-selection options.
- Initial wheel artwork drawn with Android Canvas.
- Touch-to-spin animation and basic score/spin counters.
- Original Windows resources are preserved in `app/src/main/assets/original/`.

## Reverse-engineering findings
The supplied `SpinWin.exe` is a 32-bit Windows PE program. Its imports include USER32, GDI32, WINMM, DDRAW and FMOD. The archive contains proprietary `.gfx` files, maps and OGG audio. This is not an existing portable C/C++ source tree, so direct static recompilation like a source-available port is not currently possible. The current app is a native recreation scaffold.

## Next work
1. Decode `.gfx` and map formats.
2. Reconstruct the exact wheel/menu layout and sprites.
3. Implement Memory, Bonus Ladder, Pick a Number, Scratch a Combo, Horse Racing, Quiz, Cherry Triple, Dice and Find the Spades.
4. Add original audio, trophies, save/load and scoring.
5. Test on Android hardware and produce a signed APK.

Only use/distribute game assets you are legally entitled to use.

## GFX decoding progress (validated)
The original `.gfx` files use a chunked format:
- Signature: `1XFGCSED`
- `OFNI` (byte-reversed `INFO`) contains image width, height and bit depth.
- `EGMI` (byte-reversed `IMGE`) contains the pixel payload.
- 24-bit assets are raw RGB; 16-bit assets are RGB565.
- All 18 original graphics decoded successfully to PNG and are included in `app/src/main/assets/decoded/`.
- `tools/decode_gfx.py` is a reusable decoder (Python 3 + Pillow + NumPy).

## Mini-game prototype update
Implemented native touch prototypes for Memory, Pick a Number, Scratch a Combo, Bonus Ladder and Horse Racing. These are reconstructed placeholder rules based on the original manual, not yet verified pixel-perfect replicas. The other game-token mini-games remain queued. Original GFX assets remain decoded in `app/src/main/assets/decoded/`.

## Second mini-game batch
Added playable touch prototypes for Quiz, Cherry Triple, Dice, and Find the Spades. The quiz uses a small built-in question set; Cherry Triple uses simple text symbols; Dice asks the player to match a target total; Find the Spades hides the Ace of Spades among four cards. These are original placeholder implementations and are not confirmed to match the original PC game's exact rules, payout tables, or artwork.

## Manual-based gameplay corrections (v0.5-dev)
The original `ReadMe.html` was extracted from the supplied archive and used to correct several placeholder rules:
- Wheel token counts now follow the five original mode statistics: Classic/Marathon 13 score + 10 game + 5 bonus; Stairway 14 + 10 + 4; Memory 26 + 0 + 2; Fortune 15 + 11 + 2.
- Score tokens pay 100, 250, 500 or 750 credits after Memory; Memory mode allows 3 pair attempts and the other modes 8.
- Pick a Number awards 100 credits per unopened door; Scratch a Combo pays the matched amount; Horse Racing uses the documented 4,000 / 750 / 250 prizes; Quiz pays 2,000.
- Cherry Triple now allows five plays and uses the documented cherry/triple payouts; Dice uses three dice and a 100x/200x/300x weighted sum; Find the Spades now uses a 4x4 board with a hidden four-spade row or column and pays 150 per unopened door.
- The 2x bonus is applied to the next game-token payout only, not Memory/score-token or bonus-token payouts.

This is still a reconstruction, not a verified exact port. Some original timing, wheel ordering, prize probabilities, quiz questions, animation details, and the precise interpretation of the dice payout still need comparison against a running copy of the original game. The Bonus Ladder light now alternates on a timer, but its original timing curve is not confirmed.

## Audio and trophy room update (v0.6-dev)
- Extracted the original supplied OGG sound bank into `app/src/main/assets/audio/`.
- Added Android `SoundPool` playback for wheel spins, clicks, prize sounds, dice, horse-racing, trophy unlocks, and fanfare.
- Added a Trophy Room from the main menu. It persists four achievement flags and lifetime credits with Android SharedPreferences: First Prize, High Roller (10,000 lifetime credits), Arcade Explorer (played all nine implemented mini-games), and Fortune 50K.
- The trophy screen and audio integration are preliminary; sound-to-action mapping and trophy conditions should still be compared with the original PC game.

## v0.7 visual pass
- Uses the original decoded `TitleBG.png` as the mode-selection backdrop.
- Uses the original `PricesBG.png` prize-cabinet artwork behind the trophy room.
- Uses the original `Backdrop.png` for the wheel/game screen.
- Mode selection hitboxes were adjusted to match the revised menu layout.

These are original extracted game backgrounds, not newly drawn approximations. Some controls and trophy labels remain Android overlays and are not yet pixel-perfect.

## v0.9 gameplay and progress fixes
- Horse Racing now generates a finishing order for all four horses and pays based on the horse the player selected (1st: 4,000; 2nd: 750; 3rd: 250; 4th: 0). The previous prototype selected a random finishing place independently of the player's bet, which was not a meaningful race wager.
- Memory score-token and full-board credits now contribute to lifetime credit totals, while still correctly ignoring the game-token-only 2x star.
- Horse selection rows were aligned with their visible touch targets.

These fixes improve prototype consistency; the race animation, original horse sprites, high-score table, and full original trophy collection remain to be reconstructed. The app has not yet been built or tested on a device in this environment.


## v1.0 high-score and trophy update
- Added a local top-five high-score table, persisted as JSON in SharedPreferences.
- Added a fifth trophy, Marathon Finisher, and persistent trophy/lifetime-credit progress.
- Updated Android version metadata to versionCode 2 / versionName 1.0-dev.

## Build and validation status (2026-11-04)
- Project structure checked: Gradle Kotlin DSL files, Android manifest, theme resources, Kotlin activity, decoded PNGs and OGG audio assets are present.
- All 32 decoded PNG files passed image-file validation; all 62 OGG files are present in the app audio asset folder.
- This environment does not have Gradle, the Android SDK, `adb`, or `aapt`; therefore an APK build, Android resource compilation, emulator run, and device test could not be performed.
- To build: open `SpinWinAndroid/` in Android Studio, install Android SDK Platform 35, allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
- The original game rules and presentation are only partially reconstructed. Treat this as a playable prototype source project, not a verified faithful port.

## v1.0.2 Memory gameplay fix
- Corrected Memory card touch coordinates to match the visible 4×4 grid.
- Fixed mismatched-card handling: two cards remain visible briefly, then turn face down.
- Matching a pair no longer ends the entire mini-game immediately; the player can use the remaining pair attempts.
- The Memory round ends when the configured attempts are used or all pairs are matched.
- This is a prototype-level interaction fix; exact original timing and scoring still require comparison with the PC game.

## v1.0.3 mini-game touch-control fixes
- Pick a Number tile hitboxes now align with the visible 4×4 tile grid.
- Scratch a Combo hitboxes now align with the visible 3×3 scratch-card grid; already revealed cards cannot be selected again.
- Quiz answer hitboxes now align with the visible answer buttons and ignore taps outside them.
- These are source-level fixes. An Android build and real-device touch test are still required.

## v1.0.4 Horse Racing and Find the Spades fixes
- Horse selection now only responds inside the four visible horse rows and uses the same vertical origin as the drawn rows.
- Find the Spades touch boxes now use the board's actual drawn origin and reject taps outside the board.
- The Spades game ends with its remaining-door award only after all four hidden spades have been found; the generated spades are placed in one row or column.
- Static source edits only; Android compilation and device testing remain outstanding.


## v1.0.5 build and audio packaging audit
- Configured Android asset packaging to leave `.ogg` files uncompressed, as `SoundPool` loads them through `AssetFileDescriptor`.
- Added `tools/validate_project.py` to check required Android project files and expected graphics/audio asset counts.
- Run `python3 tools/validate_project.py` from the project root for offline integrity checks.
- This check is not a substitute for Gradle compilation or testing on an Android device.

## v1.0.6 — expanded offline validation
- Expanded `tools/validate_project.py` to verify every literal graphic reference used by `MainActivity`, all twelve numbered mini-game key graphics, and every sound effect requested by the SoundPool loader.
- Also checks launcher activity declaration and uncompressed OGG configuration.
- Run from the project root with `python3 tools/validate_project.py`.
- Validation is static only. It does not prove Kotlin compilation, APK packaging, audio playback, or touchscreen behavior.

## v1.0.7 — remote APK build workflow
This project does not include a Gradle wrapper. To make a reproducible build possible without installing Android Studio locally, a GitHub Actions workflow is included at `.github/workflows/android-build.yml`.

1. Create a GitHub repository and upload/push the contents of this `SpinWinAndroid` folder to its `main` branch.
2. Open the repository's **Actions** tab and run **Android APK build** (or push to `main`/`master`).
3. Wait for the workflow to finish. If successful, download the `spinwin-debug-apk` artifact from that workflow run.

The workflow uses Java 17, Gradle 8.9, Android platform 35, and builds `:app:assembleDebug`. A successful remote build has not yet been observed; if the workflow reports compiler errors, those logs will be needed to fix them. The produced debug APK will be unsigned for Play Store release.
